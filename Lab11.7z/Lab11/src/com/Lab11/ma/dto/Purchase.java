package com.Lab11.ma.dto;

public class Purchase {

	private int purchaseId;
	private String cName,mailId,purchaseDate,phoneNo, mobileId;
	public Purchase() {
		super();
	}
	public Purchase(int purchaseId, String phoneNo, String mobileId, String cName,
			String mailId, String purchaseDate) {
		super();
		this.purchaseId = purchaseId;
		this.phoneNo = phoneNo;
		this.mobileId = mobileId;
		this.cName = cName;
		this.mailId = mailId;
		this.purchaseDate = purchaseDate;
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneno2) {
		this.phoneNo = phoneno2;
	}
	public String getMobileId() {
		return mobileId;
	}
	public void setMobileId(String mobileId) {
		this.mobileId = mobileId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	
	
}
