package com.cg.ma.dao;

import java.util.List;


import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.PurchaseDetails;

public interface IPurchaseDao {
public int addPurchaseDetails(PurchaseDetails purchase) throws MobileException;
public List<PurchaseDetails> showPurchaseDetails() throws MobileException;
}
