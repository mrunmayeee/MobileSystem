package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.JdbcUtil.JdbcUtil;
import com.cg.ma.dto.MobileDetails;

public class IMobileDaoImpl implements IMobileDao{
	Connection conn;
	PreparedStatement ps=null;
	
	@Override
	public List<MobileDetails> ShowMobileData() throws MobileException {
		
		List<MobileDetails> mobilelist=new ArrayList<MobileDetails>();
		conn=JdbcUtil.getConnection();
		String query="SELECT * from mobiles";
		try {
			ps=conn.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				MobileDetails mdetails=new MobileDetails();
				mdetails.setMobileid(rs.getInt("mobileid"));
				mdetails.setMobilename(rs.getString("name"));
				mdetails.setPrice(rs.getDouble("price"));
				mdetails.setQuantity(rs.getDouble("quantity"));
				mobilelist.add(mdetails);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Data Not Found");
		}
		finally
		{
			
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return mobilelist;
	}

	@Override
	public boolean RemoveMobileDetails(int mobileid) throws MobileException {
		conn=JdbcUtil.getConnection();
		int rec=0;
		String query="DELETE FROM mobiles where mobileid=?";
		try {
			ps=conn.prepareStatement(query);
			ps.setInt(1, mobileid);
			rec=ps.executeUpdate();
			if(rec>0)
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new MobileException("Data Not Removed");
			}
			
		}
		
		
		
		return false;
	}

	@Override
	public List<MobileDetails> SearchByPrice(double minprice, double maxprice) throws MobileException {
		conn=JdbcUtil.getConnection();
		String query="SELECT * FROM mobiles where price>=? AND price<=?";
		List<MobileDetails> mobilelist=new ArrayList<MobileDetails>();
		try {
			ps=conn.prepareStatement(query);
			ps.setDouble(1, minprice);
			ps.setDouble(2, maxprice);
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			MobileDetails mdetails=new MobileDetails();
			mdetails.setMobileid(rs.getInt("mobileid"));
			mdetails.setMobilename(rs.getString("name"));
			mdetails.setPrice(rs.getDouble("price"));
			mdetails.setQuantity(rs.getDouble("quantity"));
			mobilelist.add(mdetails);
		}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Data Not Found");
		}
		finally
		{
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		return mobilelist;
	}
	/*public static void main(String args[])
	{
		IMobileDaoImpl mobiledao=new IMobileDaoImpl();
		List<MobileDetails> mobilelist=new ArrayList<MobileDetails>();
		mobilelist=mobiledao.SearchByPrice(10000, 30000);
		for(MobileDetails m:mobilelist)
		{
			System.out.println(m);
		}
		List<MobileDetails> mobilelist=new ArrayList<MobileDetails>();
		mobilelist=mobiledao.ShowMobileData();
		for(MobileDetails m:mobilelist)
		{
			System.out.println(m);
		}
			//System.out.println(mobiledao.RemoveMobileDetails(1006));
	}*/

	@Override
	public boolean UpdateQty(int mobileid, double qty) throws MobileException {
		conn=JdbcUtil.getConnection();
		String query="UPDATE mobiles SET quantity =quantity-? where mobileid=? ";
		int rec=0;
		try {
			ps=conn.prepareStatement(query);
			ps.setDouble(1,qty);
			ps.setInt(2, mobileid);
			rec=ps.executeUpdate();
			if(rec>0)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Data is not updated");
		}
		
		return false;
	}
	

}
