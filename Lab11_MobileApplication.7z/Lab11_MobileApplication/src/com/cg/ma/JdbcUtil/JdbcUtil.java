package com.cg.ma.JdbcUtil;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class JdbcUtil {

		
		public static Connection getConnection() {
			
			 Connection conn=null;
			Properties pros=new Properties();
			try {
		InputStream fileRead=new FileInputStream("D:\\Module 2 _Java\\Myworkspace\\Lab11_MobileApplication\\Resources\\oracle.properties");
		pros.load(fileRead);
		String driver=pros.getProperty("oracle.driver");
		String url=pros.getProperty("oracle.url");
		String userName=pros.getProperty("oracle.uname");
		String password=pros.getProperty("oracle.upass");
		
		Class.forName(driver);
	conn=DriverManager.getConnection(url, userName, password);
				
	
			} catch (IOException | ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				
				
			}
			return conn;
		
	}

}
