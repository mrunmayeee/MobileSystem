package com.cg.ma.ui;

import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;

import com.cg.ma.Exception.MobileException;

import com.cg.ma.dto.MobileDetails;
import com.cg.ma.dto.PurchaseDetails;
import com.cg.ma.service.IMobileService;
import com.cg.ma.service.IMobileServiceImpl;
import com.cg.ma.service.IPurchaseService;
import com.cg.ma.service.IPurchaseServiceImpl;

public class MobileApplication {
public static void main(String args[])
{
	IMobileService mobileService=new IMobileServiceImpl();
	IPurchaseService purchaseService=new IPurchaseServiceImpl();
	int choice=0;
	do{
		printDetail();
	Scanner sc=new Scanner(System.in);
	System.out.println("Please Enter your Choice:");
	choice=sc.nextInt();
	switch(choice){
	case 1:
		String pname="^[A-Z][a-z]{2,19}$";
		System.out.println(" Enter Customer Name");
		
		String Cname=sc.next();
		try {
			IPurchaseServiceImpl.validateName(pname,Cname);
		} catch (MobileException m1) {
			
			System.out.println(m1.getMessage());
		}
		String pmail="^(.+)@(.+)$";
		System.out.println(" Enter Email Id: ");
		String emailid=sc.next();
		try {
			IPurchaseServiceImpl.validateMailid(pmail,emailid);
		} catch (MobileException m1) {
			
			System.out.println(m1.getMessage());
		}
		
		String pnum="^[7|8|9]{1}[0-9]{9}$";
		System.out.println(" Enter Phoneno:");
		String phoneno=sc.next();
		try {
			IPurchaseServiceImpl.validatePhoneno(pnum,phoneno);
		} catch (MobileException m1) {
			
			System.out.println(m1.getMessage());
		}
		
		String pmobilid="^[1]{1}[0-9]{3}$";
		System.out.println(" Enter mobileID:");
		String mobileid=sc.next();
		try {
			IPurchaseServiceImpl.validateMobilId(pmobilid,mobileid);
		} catch (MobileException m1) {
			
			System.out.println(m1.getMessage());
		}
		
		PurchaseDetails purchase=new PurchaseDetails();
		purchase.setCname(Cname);
		purchase.setMailid(emailid);
		purchase.setPhoneno(phoneno);
		purchase.setPurchasedate(purchase.getPurchasedate());
		int mid=Integer.parseInt(mobileid);
		purchase.setMobileid(mid);
	
		
		try {
			int pId=purchaseService.addPurchaseDetail(purchase);
			if(pId>0){
System.out.println("Welcome User your Purchase Id is "+pId);
			}else{
System.out.println("Data Not Inserted");
			}
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		break;
		
	case 2:
		List<PurchaseDetails> lpurchase=null;
		try {
			lpurchase = purchaseService.showPurchaseDetail();
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (PurchaseDetails pdetails : lpurchase) {
			System.out.println(" Purchase Id : "+pdetails.getPurchaseid());
			System.out.println("Customer Name :"+pdetails.getCname());
			System.out.println(" Email ID : "+pdetails.getMailid());
			System.out.println(" Phone No : " +pdetails.getPhoneno());
			System.out.println("Purchase Date: "+pdetails.getPurchasedate());
			System.out.println("Mobile ID: " +pdetails.getMobileid());
		}
		break;
		
	case 3:
		List<MobileDetails> lmobile=null;
		try {
			lmobile = mobileService.ShowAll();
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (MobileDetails mdetails : lmobile) {
			System.out.println(" Mobile Id : "+ mdetails.getMobileid());
			System.out.println("Mobile Name :"+ mdetails.getMobilename());
			System.out.println(" Price: "+ mdetails.getPrice());
			System.out.println(" Quantity : " + mdetails.getQuantity());
	}
		break;
		
	case 4:
		
		List<MobileDetails> mobilelist=new ArrayList<MobileDetails>();
System.out.println(" Enter Price Range:");
		int minprice=sc.nextInt();
		int maxprice=sc.nextInt();
		
		try {
			mobilelist= mobileService.SearchPrice(minprice, maxprice);
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(MobileDetails m:mobilelist)
		{
			System.out.println(m);
		}
		break;
		
	case 5:
		System.out.println("Enter the mobileid:");
		int rmobileid=sc.nextInt();
		try {
			System.out.println( mobileService.DeleteMobileDetails(rmobileid));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		break;
	case 6:
		System.out.println("Enter Mobile ID:");
		int qmobileid=sc.nextInt();
		System.out.println("Enter No. of mobiles sold:");
		int soldmobile=sc.nextInt();
		try {
			mobileService.UpdateQtyService(qmobileid,soldmobile);
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		break;
	case 7:
		System.exit(0);
		break;
		
		default:
			System.out.println("Please Enter Right Choice");
			break;
		
	}//sc.close();
	}while(choice!=7);
	
	
	
}
public static void printDetail(){
	System.out.println("**********");
	System.out.println("1. Add Purchase Details ");
	System.out.println("2. Show Purchase Details");
	System.out.println("3. Show All Mobiles");
	System.out.println("4. Search For Mobile");
	System.out.println("5. Remove Mobile ");
	System.out.println("6.Update Mobile Quantity");
	System.out.println("7. Exit");
	System.out.println("***********");
}
}
