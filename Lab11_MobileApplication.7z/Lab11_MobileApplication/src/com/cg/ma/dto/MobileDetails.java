package com.cg.ma.dto;

public class MobileDetails {
	private int mobileid;
	private String mobilename;
	private double price;
	private double quantity;

	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}

	public String getMobilename() {
		return mobilename;
	}

	public void setMobilename(String mobilename) {
		this.mobilename = mobilename;
	}

	public double getPrice() {
		return price;
	}

	public MobileDetails(int mobileid, String mobilename, double price,
			double quantity) {
		super();
		this.mobileid = mobileid;
		this.mobilename = mobilename;
		this.price = price;
		this.quantity = quantity;
	}

	public MobileDetails() {
		super();
	}

	public void setPrice(double price){
		this.price = price;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "MobileDetails [mobileid=" + mobileid + ", mobilename="
				+ mobilename + ", price=" + price + ", quantity=" + quantity
				+ "]";
	}

}
